package Lab;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@WebServlet("/Bai3")
public class Bai3 extends HttpServlet{
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	 resp.setContentType("text/html; charset=UTF-8");
	// TODO Auto-generated method stub
	 java.io.PrintWriter writer = resp.getWriter();
	 String url = req.getRequestURL().toString();
	    String uri = req.getRequestURI();
	    String queryString = req.getQueryString();
	    String servletPath = req.getServletPath();
	    String contextPath = req.getContextPath();
	    String pathInfo = req.getPathInfo();
	    String method = req.getMethod();

	    // Xuất thông tin ra trình duyệt
	    writer.println("<html><body style='font-family: Arial;'>");
	    writer.println("<h2>Thông tin URL hiện tại</h2>");
	    writer.println("<ul>");
	    writer.println("<li><b>URL:</b> " + url + "</li>"); 
	    writer.println("<li><b>URI:</b> " + uri + "</li>");
	    writer.println("<li><b>QueryString:</b> " + (queryString != null ? queryString : "null") + "</li>");
	    writer.println("<li><b>ServletPath:</b> " + servletPath + "</li>");
	    writer.println("<li><b>ContextPath:</b> " + contextPath + "</li>");
	    writer.println("<li><b>PathInfo:</b> " + (pathInfo != null ? pathInfo : "null") + "</li>");
	    writer.println("<li><b>Method:</b> " + method + "</li>");
	    writer.println("</ul>");
	    writer.println("</body></html>");
	}

}

