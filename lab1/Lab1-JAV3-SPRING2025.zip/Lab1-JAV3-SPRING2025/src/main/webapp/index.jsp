<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<img src="LOGO.png">
<hr />
 <a href="Bai1">Bai1 </a> || <a href="Bai2">Bai2</a> || <a href="Bai3">Bai3</a> || <a href="Bai4">Bai4</a> ||
</body>
</html>