<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Login</title>

<link rel="stylesheet" href="<c:url value='/CSS/login.css'/>">

</head>
<body>

<div class="login-box">
    
    <h2>Đăng Nhập</h2>

    <c:url value="/account/login" var="url"/>
    <form action="${url}" method="post">

        <!-- Username -->
        <div class="input-group">
            <i class="icon fa fa-user"></i>
            <input name="username" required />
            <label>Username</label>
        </div>

        <!-- Password -->
        <div class="input-group">
            <i class="icon fa fa-lock"></i>
            <input name="password" type="password" required />
            <label>Password</label>
        </div>

        <button type="submit">Login</button>
    </form>

    <p class="message">${message}</p>
</div>

<!-- FontAwesome icon -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>

</body>
</html>
