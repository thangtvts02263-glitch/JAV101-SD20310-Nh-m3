<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<html>
<head>
<meta charset="UTF-8">
<title>Calculator</title>
<link rel="stylesheet" href="${pageContext.request.contextPath}/CSS/calculate.css">

</head>
<body>

<div class="calculator-wrapper">
    <c:url value="/calculate" var="cal"/>
    <form method="post">
        <div class="input-group">
            <label>a:</label>
            <input name="a" type="number" placeholder="Enter a"/>
        </div>
        <div class="input-group">
            <label>b:</label>
            <input name="b" type="number" placeholder="Enter b"/>
        </div>
        <div class="button-group" >
            <button formaction="${cal}/add" type="submit">+</button>
            <button formaction="${cal}/sub" type="submit">-</button>
        </div>
    </form>
    <p class="message">${message}</p>
</div>

</body>
</html>
