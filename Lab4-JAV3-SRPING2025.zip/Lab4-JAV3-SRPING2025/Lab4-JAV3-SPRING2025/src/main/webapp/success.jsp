
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Thông tin đăng ký</title>
    <link rel="stylesheet" href="CSS/register.css">
</head>
<body>

<div class="register-container">
    <h2>Thông tin đăng ký</h2>
    
    <div class="input-group">
        <label>Username:</label>
        <span>${username}</span>
    </div>
    
    <div class="input-group">
        <label>Password:</label>
        <span>${password}</span>
    </div>
    
    <div class="input-group">
        <label>Email:</label>
        <span>${email}</span>
    </div>
    
    <div class="input-group">
        <label>Gender:</label>
        <span>${gender}</span>
    </div>
    
    <div class="input-group">
        <label>Hobbies:</label>
        <c:choose>
            <c:when test="${not empty hobbies}">
                <ul>
                    <c:forEach var="h" items="${hobbies}">
                        <li>${h}</li>
                    </c:forEach>
                </ul>
            </c:when>
            <c:otherwise>
                <span>Không có sở thích nào được chọn</span>
            </c:otherwise>
        </c:choose>
    </div>

    <p class="message">Bạn đã đăng ký thành công!</p>
</div>

</body>
</html>


</body>
</html>