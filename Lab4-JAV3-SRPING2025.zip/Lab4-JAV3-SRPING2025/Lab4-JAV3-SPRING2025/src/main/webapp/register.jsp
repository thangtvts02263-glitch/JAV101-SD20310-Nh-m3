<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>FORM ĐĂNG KÝ</title>
<link rel="stylesheet" href="CSS/register.css">
</head>
<body>

<div class="register-container">
    <h2>Register Form</h2>
    <form action="${pageContext.request.contextPath}/register" method="post">
        <div class="input-group">
            <label>Username:</label>
            <input name="username" type="text" placeholder="Enter username" required/>
        </div>
        <div class="input-group">
            <label>Password:</label>
            <input name="password" type="password" placeholder="Enter password" required/>
        </div>
        <div class="input-group">
            <label>Email:</label>
            <input name="email" type="email" placeholder="Enter email" required/>
        </div>
        <div class="input-group">
            <label>Gender:</label>
            <input type="radio" name="gender" value="male"/> Male
            <input type="radio" name="gender" value="female"/> Female
        </div>
        <div class="input-group">
            <label>Hobbies:</label><br/>
            <input type="checkbox" name="hobby" value="Sport"/> Sport
            <input type="checkbox" name="hobby" value="Music"/> Music
            <input type="checkbox" name="hobby" value="Reading"/> Reading
        </div>
        
        <button type="submit">Register</button>
    </form>
    <p class="message">${message}</p>
</div>

</body>
</html>
