<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Upload Image</title>
<link rel="stylesheet" href="${pageContext.request.contextPath}/CSS/upload.css">

</head>
<body>

<div class="upload-container">
    <h2>Upload Image</h2>

    <form action="${pageContext.request.contextPath}/upload"
          method="post" enctype="multipart/form-data">
        <input type="file" name="photo" required><br><br>
        <button type="submit">Upload</button>
    </form>

    <p class="message">${message}</p>

    <c:if test="${not empty imagePath}">
        <h3>Ảnh đã upload:</h3>
        <img src="${imagePath}" class="uploaded-image">
    </c:if>
</div>

</body>
</html>
