<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Poly Menu</title>
<link rel="stylesheet" type="text/css" href="CSS/style.css">
</head>
<body>

<div class="menu-container">
    <h1 class="brand">FPT POLYTECHNIC</h1>

    <nav class="menu">
        <a href="account/login" class="menu-item">Bài 1 – Login</a>
        <a href="calculate/add" class="menu-item">Bài 2 – Tính toán</a>
        <a href="register" class="menu-item">Bài 3 – Đăng ký</a>
        <a href="upload" class="menu-item">Bài 4 – Upload File</a>
    </nav>
</div>

</body>
</html>
