package poly.com.controller;

import java.io.IOException;
import java.util.Arrays;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@WebServlet("/register")
public class Bai3Controller extends HttpServlet{
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	// TODO Auto-generated method stub
	 req.getRequestDispatcher("/register.jsp").forward(req, resp);
}
@Override
protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    String username = req.getParameter("username");
    String password = req.getParameter("password");
    String email    = req.getParameter("email");
    String gender   = req.getParameter("gender");
    String[] hobbies = req.getParameterValues("hobby");

    // Gửi dữ liệu sang trang khác
    req.setAttribute("username", username);
    req.setAttribute("password", password);
    req.setAttribute("email", email);
    req.setAttribute("gender", gender);
    req.setAttribute("hobbies", hobbies);

    // Forward sang success.jsp
    req.getRequestDispatcher("/success.jsp").forward(req, resp);
}

}
