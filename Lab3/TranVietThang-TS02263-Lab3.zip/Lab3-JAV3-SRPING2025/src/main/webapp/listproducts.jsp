<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<%@ taglib uri="jakarta.tags.fmt" prefix="fmt" %>
<%@ taglib uri="jakarta.tags.functions" prefix="fn" %>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>

<style>
/* CARD layout */
.product-container {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    gap: 20px;

    /* Giới hạn 4 card mỗi hàng */
    max-width: 1200px;   /* 230px * 4 + khoảng cách */
    margin: auto;        /* Căn giữa container */
}


.product-card {
    width: 230px;
    border: 1px solid #ccc;
    padding: 12px;
    border-radius: 10px;
    text-align: center;
}

.product-card img {
    width: 210px;
    height: 210px;
    object-fit: cover;
    border-radius: 6px;
    cursor: pointer;
}

.product-name {
    font-size: 18px;
    margin-top: 10px;
    font-weight: bold;
}

.price-discount {
    margin-top: 5px;
    font-size: 15px;
}
</style>

</head>
<body>

<jsp:include page="index.jsp"></jsp:include>

<center>


<h2>Danh sách sản phẩm</h2>

<div class="product-container">

    <c:forEach var="item" items="${items}">
        <div class="product-card">

            <!-- Hình -->
            <img onClick="hamchitiet('${item.name}')"
                 src="${pageContext.request.contextPath}/img/${item.image}"
                 alt="${item.name}">

            <!-- Tên dưới hình -->
            <div class="product-name">${item.name}</div>

            <!-- Giá + khuyến mãi -->
            <div class="price-discount">
                Giá: 
                <fmt:formatNumber value="${item.price}" type="currency" currencySymbol="$"/>
                <br>
                KM: <fmt:formatNumber value="${item.discount * 100}" type="number"/>%
            </div>

            <!-- Các button -->
            <div style="margin-top: 10px;">
                <!-- Link chi tiết -->
                <a href="ProductDetailServlet?id=${item.name}">Chi tiết</a>
                <br><br>

                <!-- Button view detail -->
                <form method="get">
                    <input type="hidden" name="id" value="${item.name}">
            <button formaction="/Lab3-JAV3-SRPING2025/ProductDetailServlet">
                        View Details
                    </button>
                </form>

                <!-- Button ANH TÚ -->
                <form method="post">
                    <button formaction="/Lab3-JAV3-SRPING2025/nutthem">Thắng</button>
                </form>
            </div>

        </div>
    </c:forEach>

</div>



<!-- ====================== BẢNG THỨ 2 GIỮ NGUYÊN ===================== -->
<br><br>
<h2>Danh sách tên</h2>

<table border="1">
    <thead>
        <tr>
            <th>Số thứ tự</th>
            <th>Tên</th>
        </tr>
    </thead>
    <tbody>
        <c:forEach var="ten" items="${ds}" varStatus="status">
            <tr>
                <td>${status.index + 1}</td>
                <td>${ten}</td>
            </tr>
        </c:forEach>
    </tbody>
</table>

<hr/>

</center>

<script>
function hamchitiet(itemId) {
    window.location.href = "ProductDetailServlet?id=" + itemId;
}
</script>
</body>
</html>
