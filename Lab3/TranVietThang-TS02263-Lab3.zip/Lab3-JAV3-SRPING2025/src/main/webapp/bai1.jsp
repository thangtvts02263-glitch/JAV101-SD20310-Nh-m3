<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<%@ taglib uri="http://java.sun.com/jstl/core_rt" prefix="c" %> 

<html>
<head>
<meta charset="UTF-8">
<title>Country</title>
</head>
<h1> COUNTRY</h1>

<body>
<a href="bai1">Bài 1</a>
<a href="bai2">Bài 2</a>
<a href="bai3">Bài 3</a>
<a href="bai4">Bài 4</a>
<hr>
<select name="Country"> 
 <c:forEach var="ct" items="${countries}"> 
  <option value="${ct.id}">${ct.name}</option> 
 </c:forEach>
</body>
</html>