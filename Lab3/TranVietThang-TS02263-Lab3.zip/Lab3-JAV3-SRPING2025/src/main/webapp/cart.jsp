<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<%@ taglib uri="jakarta.tags.fmt" prefix="fmt" %>
<%@ taglib uri="jakarta.tags.functions" prefix="fn" %>
<html>
<head>
    <meta charset="UTF-8">
    <title>Shopping Cart</title>
</head>
<body>
   <h1>Danh sách sản phẩm</h1>

<div style="display: flex; flex-wrap: wrap; gap: 20px;">

    <c:forEach var="item" items="${items}">
        <div style="
            width: 230px;
            border: 1px solid #ccc;
            padding: 10px;
            border-radius: 8px;
        ">
            <!-- Hình ảnh -->
            <img src="${pageContext.request.contextPath}/img/${item.image}" 
                 alt="${item.name}" 
                 width="210"
                 height="210"
                 style="object-fit: cover; display:block; margin:auto;">

            <!-- Tên -->
            <h3 style="margin: 8px 0 5px 0; text-align:center;">
                ${item.name}
            </h3>

            <!-- Giá + Khuyến mãi -->
            <p style="text-align:center;">
                Giá: 
                <fmt:formatNumber value="${item.price}" type="currency" currencySymbol="$"/>
                <br>
                KM: <fmt:formatNumber value="${item.discount * 100}" type="number"/>%
            </p>

            <!-- Thao tác -->
            <form action="CartController1" method="get" style="text-align:center;">
                <input type="hidden" name="action" value="add">
                <input type="hidden" name="itemName" value="${item.name}">
                <label>Số lượng:</label>
                <input type="number" name="quantity" min="1" required value="1" style="width:60px;">
                <br><br>
                <input type="submit" value="Thêm vào giỏ">
            </form>

        </div>
    </c:forEach>

</div>


    <h2>Giỏ hàng</h2>
    <c:if test="${not empty cartItems}">
        <table border="1">
            <thead>
                <tr>
                    <th>Tên sản phẩm</th>
                    <th>Số lượng</th>
                    <th>Giá</th>
                    <th>Tổng giá</th>
                    <th>Thao tác</th>
                </tr>
            </thead>
            <tbody>
                <c:forEach var="cartItem" items="${cartItems}">
                    <tr>
                        <td>${cartItem.item.name}</td>
                        <td>
                            <form action="CartController1" method="get" style="display: inline;">
                                <input type="hidden" name="action" value="update">
                                <input type="hidden" name="itemName" value="${cartItem.item.name}">
                                <input type="number" name="quantity" value="${cartItem.quantity}" min="1" required>
                                <input type="submit" value="Cập nhật">
                            </form>
                        </td>
                        <td><fmt:formatNumber value="${cartItem.item.price}" type="currency" currencySymbol="$"/></td>
                        <td><fmt:formatNumber value="${cartItem.getTotalPrice()}" type="currency" currencySymbol="$"/></td>
                        <td>
                            <form action="CartController1" method="get" style="display: inline;">
                                <input type="hidden" name="action" value="remove">
                                <input type="hidden" name="itemName" value="${cartItem.item.name}">
                                <input type="submit" value="Xóa">
                            </form>
                            <a href="/Lab3-JAV3-SRPING2025/remove?itemName=${cartItem.item.name}">xóa</a>
                            <a href="CartController1?action=remove&itemName=${cartItem.item.name}">xóa 1</a>
                        </td>
                    </tr>
                </c:forEach>
            </tbody>
        </table>
        <h3>Tổng giá giỏ hàng: <fmt:formatNumber value="${totalPrice}" type="currency" currencySymbol="$"/></h3>
    </c:if>
    
    <c:if test="${empty cartItems}">
        <p>Giỏ hàng của bạn đang trống.</p>
    </c:if>
    
    <hr/>
</body>
</html>
