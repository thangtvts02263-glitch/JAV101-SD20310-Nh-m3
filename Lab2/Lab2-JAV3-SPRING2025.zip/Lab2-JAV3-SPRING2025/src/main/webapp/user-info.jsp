<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<b>YOUR INFORMATION</b>
    <ul>
        <li>Fullname: ${user.fullname}</li>
        <li>Phái: ${user.gender}</li>
        <li>Quốc tịch: ${user.country}</li>
    </ul>
</body>
</html>