<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<form action="/Lab2-JAV3-SPRING2025 /form/ud" method="post">
    Full Name: ${user.fullname}
    <br>
    <input type="text" name="fullname" value="${user.fullname}">
    <br>
    Country:
    <select name="country">
        <option value="VN" ${user.country == 'VN' ? 'selected' : ''}>Viet Nam</option>
        <option value="US" ${user.country == 'US' ? 'selected' : ''}>United States</option>
        <option value="CN" ${user.country == 'CN' ? 'selected' : ''}>China</option>
    </select>
    <br>
    Gender: ${user.gender}
    <input type="radio" name="gender" value="true" ${user.gender == true ? 'checked' : ''}>Male
    <input type="radio" name="gender" value="false" ${user.gender == false ? 'checked' : ''}>Female
    <br>
    <hr>
    <p>Gender: ${user.gender }</p>
    <button formaction="/Lab2-JAV3-SPRING2025/form/create">Create</button>
    <button>UPDATE</button>
    ${capnhat }
</form>
</body>
</html>